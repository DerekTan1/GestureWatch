/* Comments for all functions are located in the prototypes.h file */

#include <msp430.h>
#include "globals.h"
#include "constants.h"
#include "io_pins.h"
#include "prototypes.h"

void UpdateClock(void)
{
    s++;
    if (s >= 60)
    {
        s = 0;
        m++;
        if (m >= 60)
        {
            m = 0;
            h++;
            if (h >= 12)
            {
                h = 0;
            }
        }
    }
}

void UpdateFastClock(void)
{
    fast_s++;
    if (fast_s >= 60)
    {
        fast_s = 0;
        fast_m++;
        if (fast_m >= 60)
        {
            fast_m = 0;
            fast_h++;
            if (fast_h >= 12)
            {
                fast_h = 0;
            }
        }
    }
}
