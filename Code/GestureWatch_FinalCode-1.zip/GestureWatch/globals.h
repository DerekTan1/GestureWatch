#ifndef GLOBALS_H
#define GLOBALS_H

#include <stdbool.h>
#include <stdint.h>

/* This variable is incremented by the interrupt handler and */
/* decremented by a software call in the main loop. */
extern unsigned int g1ms_timeout;

/* This variable is incremented in ManageSoftwareTimers */
extern unsigned int g1ms_timer;

extern int count_to_one_second;
extern int count_has_changed;

extern unsigned char h, m, s;
extern unsigned char fast_h, fast_m, fast_s;

extern unsigned char led_data[36];

extern unsigned char led_data2[36];
extern uint8_t sensor_data[14];

extern int16_t gx, gy, gz, ax, ay, az;
extern int gx_bias, gy_bias, gz_bias, ax_bias, ay_bias, az_bias;
extern int offset_table, offset_arm;
extern int forwards, backwards, vibe, gesture_detected;

extern int level_held, level, condition_length, plus_ax, minus_ax, plus_ay, minus_ay,
        plus_az, minus_az, plus_gx, minus_gx, plus_gy, minus_gy, plus_gz, minus_gz;

extern bool switch_reset;

extern unsigned char state;
extern unsigned char pushed;

/* Type Definitions */
typedef enum
{
    DbExpectHigh, DbValidateHigh, DbExpectLow, DbValidateLow
} DbState;

typedef enum
{
    Low, High
} SwitchStatus;

typedef struct
{
    DbState CurrentState;           /* Current state of the FSM */
    char * SwitchPort;              /* Input port associated with switch */
    unsigned char SwitchPortBit;    /* Port pin associated with switch */
    unsigned char HoldTime;         /* Time switch must remain On */
    unsigned char ReleaseTime;     /* Time switch must remain Off after being On */
    unsigned int EventTime;         /* Records time of an event */
} SwitchDefine;

extern volatile SwitchStatus push_button_status;
extern SwitchDefine PushButton;

#endif
