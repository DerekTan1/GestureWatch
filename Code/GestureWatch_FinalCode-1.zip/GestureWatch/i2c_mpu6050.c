/* Comments for all functions are located in the prototypes.h file */

#include <msp430.h>
#include "globals.h"
#include "io_pins.h"

void InitializeI2CPortPins(void)
{
    /* Initialize the value and port pin direction of I2C. */
    TURN_ON_SCL;
    SET_SCL_AS_AN_OUTPUT;
    TURN_ON_SDA;
    SET_SDA_AS_AN_OUTPUT;
    TURN_ON_LED;
    SET_LED_AS_AN_OUTPUT;
}

void i2c_dly(void)
{
}

void i2c_start(void)
{
    TURN_ON_SDA;
    i2c_dly();
    TURN_ON_SCL;
    i2c_dly();
    TURN_OFF_SDA;
    i2c_dly();
    TURN_OFF_SCL;
    i2c_dly();
}

void i2c_stop(void)
{
    TURN_OFF_SDA;
    i2c_dly();
    TURN_ON_SCL;
    i2c_dly();
    TURN_ON_SDA;
    i2c_dly();
}

unsigned char i2c_rx(char ack)
{
    char x, d = 0;
    TURN_ON_SDA;
    SET_SDA_AS_AN_INPUT;
    for (x = 0; x < 8; x++)
    {
        d <<= 1;
        SET_SCL_AS_AN_INPUT;
        do
        {
            TURN_ON_SCL;
        }
        while (SCL_IN == 0);
        SET_SCL_AS_AN_OUTPUT;
        i2c_dly();
        if (SDA_IN)
            d |= 1;
        TURN_OFF_SCL;
    }
    SET_SDA_AS_AN_OUTPUT;
    if (ack)
        TURN_OFF_SDA;
    else
        TURN_ON_SDA;
    TURN_ON_SCL;
    i2c_dly();
    TURN_OFF_SCL;
    TURN_ON_SDA;
    return d;
}

bool i2c_tx(uint8_t d)
{
    char x;
    static bool b;
    for (x = 8; x; x--)
    {
        if (d & 0x80)
            TURN_ON_SDA;
        else
            TURN_OFF_SDA;
        TURN_ON_SCL;
        d <<= 1;
        TURN_OFF_SCL;
    }
    TURN_ON_SDA;
    SET_SDA_AS_AN_INPUT;
    TURN_ON_SCL;
    i2c_dly();
    b = SDA_IN;
    TURN_OFF_SCL;
    SET_SDA_AS_AN_OUTPUT;
    return b;
}

void WriteByte(uint8_t address, uint8_t subAddress, uint8_t data)
{
    i2c_start();
    i2c_tx(address * 2);
    i2c_tx(subAddress);
    i2c_tx(data);
    i2c_stop();
}

uint8_t ReadByte(uint8_t address, uint8_t subAddress)
{
    i2c_start();
    i2c_tx(address * 2);
    i2c_tx(subAddress);
    i2c_start();
    i2c_tx(address * 2 + 1);
    uint8_t data = i2c_rx(0);
    i2c_stop();
    return data;
}

void ReadBytes(uint8_t address, uint8_t subAddress, uint8_t count,
               uint8_t * dest)
{
    int i;
    i2c_start();
    i2c_tx(address * 2);
    i2c_tx(subAddress);
    i2c_start();
    i2c_tx(address * 2 + 1);
    for (i = 0; i < count - 1; i++)
    {
        dest[i] = i2c_rx(1);
    }
    dest[count - 1] = i2c_rx(0);
    i2c_stop();
}
