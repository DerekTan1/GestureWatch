#ifndef IO_PINS_H
#define IO_PINS_H

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *              Pushbutton
 *     (for detection pushbutton input)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   GPIO      :  P3.6
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define PUSHBUTTON
#define PUSHBUTTON_BIT                      BIT6    /* Port pin bit location for pushbutton */
/*#define PUSHBUTTON_REN                    P1REN   Register to enable resistors for pushbutton Not available on f1611 */
#define PUSHBUTTON_PORT_IN                  P3IN    /* Register to read port pin input */
#define PUSHBUTTON_PORT                     P3OUT   /* Register to select pull-up/pull-down */
#define PUSHBUTTON_DDR                      P3DIR   /* Data Direction Register (DDR) for pushbutton. */
#define SET_PUSHBUTTON_TO_AN_INPUT          PUSHBUTTON_DDR &= ~PUSHBUTTON_BIT
/*#define ENABLE_PULL_UP_PULL_DOWN_RESISTORS    PUSHBUTTON_REN |= PUSHBUTTON_BIT Not on msp430f1611 */
#define SELECT_PULL_UP_RESISTORS            PUSHBUTTON_PORT |= PUSHBUTTON_BIT



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *               Vibration
 *   (For controlling vibration motor)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   GPIO      :  P2.0
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define VIBRATION
#define VIBRATION_BIT                       BIT0    /* Port pin bit location for pushbutton */
#define VIBRATION_PORT_IN                   P2IN    /* Register to read port pin input */
#define VIBRATION_PORT                      P2OUT   /* Register to select pull-up/pull-down */
#define VIBRATION_DDR                       P2DIR   /* Data Direction Register (DDR) for pushbutton. */
#define TURN_ON_VIBRATION                   VIBRATION_PORT |= VIBRATION_BIT
#define TURN_OFF_VIBRATION                  VIBRATION_PORT &= ~VIBRATION_BIT
#define SET_VIBRATION_TO_AN_OUTPUT          VIBRATION_DDR |= VIBRATION_BIT



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *                 SCL
 *  (for I2C communication with MPU6050)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   GPIO      :  P4.6
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define SCL
#define SCL_BIT                 BIT6
#define SCL_PORT                P4OUT
#define SCL_DDR                 P4DIR
#define SET_SCL_AS_AN_OUTPUT    SCL_DDR |= SCL_BIT
#define SET_SCL_AS_AN_INPUT     SCL_DDR &= ~SCL_BIT
#define TURN_ON_SCL             SCL_PORT |= SCL_BIT
#define TURN_OFF_SCL            SCL_PORT &= ~SCL_BIT
#define TOGGLE_SCL              SCL_PORT ^= SCL_BIT /*Not used */
#define SCL_IN                  P4IN & BIT6



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *                 SDA
 *  (for I2C communication with MPU6050)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   GPIO      :  P4.5
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
#define SDA
#define SDA_BIT                 BIT5
#define SDA_PORT                P4OUT
#define SDA_DDR                 P4DIR
#define SET_SDA_AS_AN_OUTPUT    SDA_DDR |= SDA_BIT
#define SET_SDA_AS_AN_INPUT     SDA_DDR &= ~SDA_BIT
#define TURN_ON_SDA             SDA_PORT |= SDA_BIT
#define TURN_OFF_SDA            SDA_PORT &= ~SDA_BIT
#define TOGGLE_SDA              SDA_PORT ^= SDA_BIT /*Not used */
#define SDA_IN                  P4IN & BIT5



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *                 LED
 *      (for sending data to LED ring)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   GPIO      :  P6.3
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
#define LED
#define LED_BIT                 BIT3
#define LED_PORT                P6OUT
#define LED_DDR                 P6DIR
#define SET_LED_AS_AN_OUTPUT    LED_DDR |= LED_BIT
#define SET_LED_AS_AN_INPUT     LED_DDR &= ~LED_BIT /*Not used */
#define TURN_ON_LED             LED_PORT |= LED_BIT
#define TURN_OFF_LED            LED_PORT &= ~LED_BIT
#define TOGGLE_LED              LED_PORT ^= LED_BIT /*Not used */
#define LED_IN                  P6IN & BIT3 /*Not used */

#endif
