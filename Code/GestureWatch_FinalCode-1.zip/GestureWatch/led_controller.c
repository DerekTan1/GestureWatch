/* Comments for all functions are located in the prototypes.h file */

#include <msp430.h>
#include "globals.h"
#include "io_pins.h"

void SendData(void)
{
    unsigned char i, j, k;
    for (i = 0; i < 12; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 7; k < 8; k--)
            { /*k<8 because (unsigned 0) - (unsigned 1) equals INT_M_ax; */
                if ((led_data[j + i * 3] >> k) & 0x01)
                {
                    TURN_ON_LED;
                    TURN_ON_LED;
                    TURN_OFF_LED;
                }
                else
                {
                    TURN_ON_LED;
                    TURN_OFF_LED;
                }
            }
        }
    }
}

void ClearLEDs(void)
{
    unsigned char i;
    for (i = 0; i < 36; i++)
    {
        led_data[i] = 0;
    }
}

void ShowClock(void)
{
    unsigned char i;
    for (i = 0; i < 36; i++)
    {
        led_data[i] = 0;
    }
    led_data[1 + 3 * h] = 20;
    led_data[2 + 3 * (m / 5)] = 20;
    led_data[0 + 3 * (((m % 5) * 60 + s) / 25)] = 10;
}

void ShowFastClock(void)
{
    unsigned char i;
    for (i = 0; i < 36; i++)
    {
        led_data[i] = 0;
    }
    led_data[1 + 3 * fast_h] = 20;
    led_data[2 + 3 * (fast_m / 5)] = 20;
    led_data[0 + 3 * (((fast_m % 5) * 60 + fast_s) / 25)] = 10;
}

void ShowTilt()
{
    ClearLEDs();
    if (ax - ax_bias > -offset_table && ax - ax_bias < offset_table
            && ay - ay_bias > -offset_table && ay - ay_bias < offset_table
            && az - az_bias > -offset_table && az - az_bias < offset_table)
    {
        led_data[0 + 3 * 1] = 10;
        led_data[0 + 3 * 2] = 10;
        led_data[0 + 3 * 4] = 10;
        led_data[0 + 3 * 5] = 10;
        led_data[0 + 3 * 7] = 10;
        led_data[0 + 3 * 8] = 10;
        led_data[0 + 3 * 10] = 10;
        led_data[0 + 3 * 11] = 10;
    }
    else
    {
        if (ax > 15000)
        {
            led_data[3 * 3 + 2] = 20;
        }
        if (ax < -15000)
        {
            led_data[3 * 9 + 2] = 20;
        }
        if (ay > 15000)
        {
            led_data[3 * 0 + 2] = 20;
        }
        if (ay < -15000)
        {
            led_data[3 * 6 + 2] = 20;
        }
    }
}
