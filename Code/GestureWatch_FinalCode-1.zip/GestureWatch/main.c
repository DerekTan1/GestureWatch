/* Comments for all functions are located in the prototypes.h file */

#include <msp430.h>
#include "globals.h"
#include "constants.h"
#include "io_pins.h"
#include "prototypes.h"

unsigned char h = 6, m = 43, s = 15;
unsigned char fast_h = 0, fast_m = 0, fast_s = 0;

unsigned char led_data[36] = { };

unsigned char led_data2[36] = { };
uint8_t sensor_data[14] = { };

int16_t gx = 0, gy = 0, gz = 0, ax = 0, ay = 0, az = 0;
int gx_bias = -216, gy_bias = -21, gz_bias = 5, ax_bias = -175, ay_bias = 311,
        az_bias = 17013;
int offset_table = 2000, offset_arm = 5000;
int forwards = 0, backwards = 0, vibe = 0, gesture_detected = 0;

int level_held = 0, level = 0, condition_length = 0, plus_ax = 0, minus_ax = 0,
        plus_ay = 0, minus_ay = 0, plus_az = 0, minus_az = 0, plus_gx = 0,
        minus_gx = 0, plus_gy = 0, minus_gy = 0, plus_gz = 0, minus_gz = 0;

bool switch_reset = true;

unsigned char state = 0;
unsigned char pushed = 0;

unsigned int g1ms_timeout = 0;
unsigned int g1ms_timer = 0;

int count_has_changed = 0;

void main(void)
{
    /* Stop the watchdog timer, and configure the clock module. */
    WDTCTL = WDTPW + WDTHOLD;
    ConfigureClockModule();

    /* here from UART example, not sure if we need it */
    volatile unsigned int i;
    do
    {
        IFG1 &= ~OFIFG; /* Clear OSCFault flag */
        for (i = 0xFF; i > 0; i--)
            ; /* Time for flag to set */
    }
    while ((IFG1 & OFIFG)); /* OSCFault flag still set? */

    InitializeUART();

    /* Initialize port pins associated with I2C. */
    InitializeI2CPortPins();

    /* Initialize port pin associated with pushbutton */
    InitializePushButtonPortPin();

    /* Configure timer A to generate the required interrupt. */
    ConfigureTimerA();

    /* Initialize the pushbutton switch. */
    InitializeSwitch(&PushButton, (char *) &PUSHBUTTON_PORT_IN,
                     (unsigned char) PUSHBUTTON_BIT,
                     HIGH_THRESHOLD,
                     LOW_THRESHOLD);

    _enable_interrupts();

    /*  Infinite loop */
    while (1)
    {
        if (count_has_changed != count_to_one_second)
        {
            count_has_changed = count_to_one_second;
            if (count_to_one_second == 128)
            {
                UpdateClock();
                count_to_one_second = 0;
            }
            UpdateFastClock();
            g1ms_timeout++;

            CheckButton();

            switch (state)
            {
            case 0:
                ClearLEDs();
                break;
            case 1:
                ShowClock();
                break;
            case 2:
                ShowFastClock();
                break;
            case 3:
                if (pushed == 1)
                {
                    WriteByte(MPU6050_ADDRESS, PWR_MGMT_1, 0x80);
                    __delay_cycles(10000);
                    WriteByte(MPU6050_ADDRESS, PWR_MGMT_1, 0x00);
                }
                else
                {
                    ReadGyro();
                    ReadAccel();
                    ShowTilt();
                }
                break;
            case 4:
                ReadGyro();
                ReadAccel();
                CheckGesture();
                break;
            default:
                break;
            }
            pushed = 0;
            SendData();
        }
    }
}

void ConfigureClockModule(void)
{
    DCOCTL |= (DCO2 + DCO1 + DCO0);
    BCSCTL1 |= (RSEL2 + RSEL1 + RSEL0);
    BCSCTL2 |= 0x01; /* 0x01 and add resistor between pins 1 and 25 for high speed clock */
    BCSCTL1 |= DIVA_3; /* ACLK/8 */
}

void ManageSoftwareTimers(void)
{
    if (g1ms_timeout)
    {
        g1ms_timeout--;
        g1ms_timer++;
    }
}

void CheckButton(void)
{
    ManageSoftwareTimers();
    push_button_status = Debouncer(&PushButton);
    if (push_button_status == Low)
    { /* Switch is inactive */
        switch_reset = true;
    }
    else
    {
        if (switch_reset == true)
        {
            switch (state)
            {
            case 0:
                state++;
                pushed = 1;
                break;
            case 1:
                state++;
                pushed = 1;
                break;
            case 2:
                state++;
                pushed = 1;
                break;
            case 3:
                state++;
                pushed = 1;
                break;
            case 4:
                state = 0;
                pushed = 1;
                break;
            default:
                break;
            }
        }
        switch_reset = false;
    }
}
