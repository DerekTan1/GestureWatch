/* Comments for all functions are located in the prototypes.h file */

#include <msp430.h>
#include "globals.h"
#include "constants.h"
#include "io_pins.h"
#include "prototypes.h"

void ReadGyro()
{
    uint8_t raw_data[6];  /* x/y/z gyro register data stored here */
    ReadBytes(MPU6050_ADDRESS, GYRO_XOUT_H, 6, &raw_data[0]); /* Read the two raw data registers sequentially into data array */
    gx = ((int16_t) raw_data[0]) << 8 | raw_data[1]; /* Turn the MSB and LSB into a 16-bit value */
    gy = ((int16_t) raw_data[2]) << 8 | raw_data[3]; /* Turn the MSB and LSB into a 16-bit value */
    gz = ((int16_t) raw_data[4]) << 8 | raw_data[5]; /* Turn the MSB and LSB into a 16-bit value */
}

void ReadAccel()
{
    uint8_t raw_data[6];  /* x/y/z gyro register data stored here */
    ReadBytes(MPU6050_ADDRESS, ACCEL_XOUT_H, 6, &raw_data[0]); /* Read the two raw data registers sequentially into data array */
    ax = ((int16_t) raw_data[0]) << 8 | raw_data[1]; /* Turn the MSB and LSB into a 16-bit value */
    ay = ((int16_t) raw_data[2]) << 8 | raw_data[3]; /* Turn the MSB and LSB into a 16-bit value */
    az = ((int16_t) raw_data[4]) << 8 | raw_data[5]; /* Turn the MSB and LSB into a 16-bit value */
}

void CheckGesture()
{
    /* Clear LEDs because we are going to be using them. */
    ClearLEDs();
    int vibe_time = 64, force = 30000, gesture_time = 64, oneSecond = 128; /* 128 = 1 second */

    /* Decrement all counters that are above zero.
       This is how I track what motion conditions have
       been present in the recent past. And which ones
       have been present more recently than others.
       There are better ways to do this. But this was the
       fastest way I thought of and it works well enough.
       Although I could do much to fine tune the values. */
    if (gesture_detected > 0){
        gesture_detected--;
    }
    if (forwards > 0){
        forwards--;
    }
    if (backwards > 0){
        backwards--;
    }
    if (vibe > 0){
        vibe--;
    }
    if (level > 0){
        level--;
    }
    if (plus_ax > 0){
        plus_ax--;
    }
    if (minus_ax > 0){
        minus_ax--;
    }
    if (plus_ay > 0){
        plus_ay--;
    }
    if (minus_ay > 0){
        minus_ay--;
    }
    if (plus_az > 0){
        plus_az--;
    }
    if (minus_az > 0){
        minus_az--;
    }
    if (plus_gx > 0){
        plus_gx--;
    }
    if (minus_gx > 0){
        minus_gx--;
    }
    if (plus_gy > 0){
        plus_gy--;
    }
    if (minus_gy > 0){
        minus_gy--;
    }
    if (plus_gz > 0){
        plus_gz--;
    }
    if (minus_gz > 0){
        minus_gz--;
    }

    /* If we have not detected a gesture too recently, enter here and check data for a new gesture */
    if (gesture_detected == 0)
    {
        if (ax - ax_bias > -offset_arm && ax - ax_bias < offset_arm
                && ay - ay_bias > -offset_arm && ay - ay_bias < offset_arm
                && az - az_bias > -offset_arm && az - az_bias < offset_arm)
        {
            level = gesture_time;
        }
        if (ax - ax_bias > force){
            plus_ax = gesture_time;
        }
        if (ax - ax_bias < -force){
            minus_ax = gesture_time;
        }
        if (ay - ay_bias > force){
            plus_ay = gesture_time;
        }
        if (ay - ay_bias < -force){
            minus_ay = gesture_time;
        }
        if (az - az_bias > force){
            plus_az = gesture_time;
        }
        if (az - az_bias < -force){
            minus_ay = gesture_time;
        }
        if (gx - gx_bias > force){
            plus_gx = gesture_time;
        }
        if (gx - gx_bias < -force){
            minus_gx = gesture_time;
        }
        if (gy - gy_bias > force){
            plus_gy = gesture_time;
        }
        if (gy - gy_bias < -force){
            minus_gy = gesture_time;
        }
        if (gz - gz_bias > force){
            plus_gz = gesture_time;
        }
        if (gz - gz_bias < -force){
            minus_gz = gesture_time;
        }

        /* Detect left hand waving down and to the right */
        if (gy - gy_bias < -force && az > 0)
        {
            gesture_detected = gesture_time;
            vibe = vibe_time;
            SendStringToBluetooth("+\r\n");
            ClearMotionTracking();
            forwards = oneSecond;
        }

        /* Detect left hand waving up and to the left */
        if (gy - gy_bias > force && az > 5000)
        {
            gesture_detected = gesture_time;
            vibe = vibe_time;
            SendStringToBluetooth("-\r\n");
            ClearMotionTracking();
            backwards = oneSecond;
        }

        /* Detect left hand facing palm-up, then rising up */
        if (gy - gy_bias < -force && az < -10000)
        {
            gesture_detected = gesture_time;
            vibe = vibe_time;
            SendStringToBluetooth("a\r\n");
            ClearMotionTracking();
        }

        /* Detect left hand twisting to the left
           Currently serves the same function as the
           following, right twist code, but previously was
           used independently. */
        if (level > 0 && minus_ay > level && plus_ay > minus_ay)
        {
            gesture_detected = gesture_time;
            vibe = vibe_time;
            SendStringToBluetooth("s\r\n");
            ClearMotionTracking();
        }

        /* Detect left hand twisting to the right */
        if (level > 0 && plus_ay > level && minus_ay > plus_ay)
        {
            gesture_detected = gesture_time;
            vibe = vibe_time;
            SendStringToBluetooth("s\r\n");
            ClearMotionTracking();
        }
    }

    /* Sets LED data to display an arrow pointing towards the fingers */
    if (forwards > 0)
    {
        led_data[0 + 3 * 2] = 10;
        led_data[1 + 3 * 2] = 20;
        led_data[0 + 3 * 3] = 10;
        led_data[1 + 3 * 3] = 20;
        led_data[0 + 3 * 4] = 10;
        led_data[1 + 3 * 4] = 20;
        led_data[0 + 3 * 9] = 10;
        led_data[1 + 3 * 9] = 20;
    }

    /* Sets LED data to display an arrow pointing towards the elbow */
    if (backwards > 0)
    {
        led_data[0 + 3 * 3] = 10;
        led_data[1 + 3 * 3] = 20;
        led_data[0 + 3 * 8] = 10;
        led_data[1 + 3 * 8] = 20;
        led_data[0 + 3 * 9] = 10;
        led_data[1 + 3 * 9] = 20;
        led_data[0 + 3 * 10] = 10;
        led_data[1 + 3 * 10] = 20;
    }

    /* These two if statements control turning the vibration motor on and off */
    if (vibe > 0){
        TURN_ON_VIBRATION;
    }
    if (vibe <= 0){
        TURN_OFF_VIBRATION;
    }
}

void ClearMotionTracking(void)
{
    level = 0;
    plus_ax = 0;
    minus_ax = 0;
    plus_ay = 0;
    minus_ay = 0;
    plus_az = 0;
    minus_az = 0;
    plus_gx = 0;
    minus_gx = 0;
    plus_gy = 0;
    minus_gy = 0;
    plus_gz = 0;
    minus_gz = 0;
    backwards = 0;
    forwards = 0;
}
