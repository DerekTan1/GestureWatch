#ifndef PROTOTYPES_H
#define PROTOTYPES_H

/*Defined in main.c */
/*
This function configures the software clock.
We use an external resistor to reach a clock speed of 8.4 MHz
*/
void ConfigureClockModule(void);

/*
This function manages the 1 ms timer.
Because of our clock settings, this is not actually timing 1 millisecond.
This is only used for pushbutton debouncing.
*/
void ManageSoftwareTimers(void);

/*
This function handles checking the pushbutton and changing the current state based on the input.
*/
void CheckButton(void);





/*Defined in timerA.c */
/*
This function configures TimerA which is what we use to keep time and trigger all updates.
Currently, nothing runs without TimerA first putting things in motion.
This was done partially because the interrupt from TimerA could mess with things like i2c communication.
*/
void ConfigureTimerA(void);





/*Defined in uart_rn42.c */
/*
Initialize the MSP430F1611 for UART transmissions.
*/
void InitializeUART(void);

/*
Sends a character over the UART
*/
void SendUART(int data);

/*
Sends a string of characters over UART to the RN42 bluetooth module.
*/
void SendStringToBluetooth(char str[]);





/*Defined in button.c */
/*
Initializes the pushbutton I/O pin.
*/
void InitializePushButtonPortPin(void);

/*
Initializes switch used for pushbutton debouncing.
*/
void InitializeSwitch(SwitchDefine *Switch,char *switch_port,unsigned char switch_bit,
        unsigned char hold_time,unsigned char release_time);

/*
This function returns the instantaneous value of the selected switch
*/
SwitchStatus GetSwitch(SwitchDefine *Switch);

/*
This function debounces a switch input
*/
SwitchStatus Debouncer(SwitchDefine *Switch);





/*Defined in i2c_mpu6050.c */
/*
This function initializes the two I/O pins used for our software defined i2c implementation,
SCL and SDA.
*/
void InitializeI2CPortPins(void);

/*
This is just an empty function to add a tiny delay in the i2c functions.
This function is intentionally empty.
*/
void i2c_dly(void);

/*
This function starts an i2c transmission.
*/
void i2c_start(void);

/*
This function ends an i2c transmission.
*/
void i2c_stop(void);

/*
This function reads a byte from i2c.
*/
unsigned char i2c_rx(char ack);

/*
This function sends a byte out over i2c.
*/
bool i2c_tx(unsigned char d);

/*
This function writes to a specific register on the MPU6050 target device.
The first parameter is the address of the MPU6050, the second parameter is
the address of the register to be written, the third parameter contains the
data to be written.
*/
void WriteByte(uint8_t address, uint8_t subAddress, uint8_t data);

/*
This function reads from a specific register on the MPU6050 target device.
The first parameter is the address of the MPU6050, the second parameter is
the address of the register to be read.
*/
uint8_t ReadByte(uint8_t address, uint8_t subAddress);

/*
This function reads from specific registers in series on the MPU6050 target device.
The first parameter is the address of the MPU6050, the second parameter is
the address of the first register to be read, the third parameter is the number of
sequential registers to be read, and the fourth parameter is a pointer to a location
to store the data that is read.
*/
void ReadBytes(uint8_t address, uint8_t subAddress, uint8_t count, uint8_t * dest);





/*Defined in motion_processing.c */
/*
This function reads the X, Y, and Z gyroscope values from the MPU6050
*/
void ReadGyro(void);

/*
This function reads the X, Y, and Z accelerometer values from the MPU6050
*/
void ReadAccel(void);

/*
This function is the main gesture interpretation function.
Further comments appear within the function definition for this one.
*/
void CheckGesture(void);

/*
This is a helper function for the CheckGesture() function.
All this does is reset any saved motion data back to zeros.
When we detect a gesture, we no longer care about any data
stored before that gesture was detected. So we reset it.
*/
void ClearMotionTracking(void);





/*Defined in led_controller.c */
/*
This function sends the current LED data array to the LED display
*/
void SendData(void);

/*
This function clears the LED data array so that a subsequent call to
SendData() would send a full blank array and turn the LED fully off.
*/
void ClearLEDs(void);

/*
This function sends the current time data to the LED display in our
red/blue/green clock hand format.
*/
void ShowClock(void);

/*
This function sends the current fast clock (example) data to the LED display in our
red/blue/green clock hand format.
*/
void ShowFastClock(void);

/*
This function sends data to the display based on the current position of the watch.
A level position will show green, and tilted all the way to the +X, -X, +Y, or -Y directions
will show a blue LED light up in that direction.
*/
void ShowTilt(void);





/*Defined in clock_handler.c */
/*
This function updates the main time-keeping clock, based on a 32kHz watch crystal
*/
void UpdateClock(void);

/*
This function updates the fast clock. This clock doesn't keep time in any reasonable way.
This is only used to show the clock hands moving fast as a test and demo mode.
*/
void UpdateFastClock(void);

#endif
