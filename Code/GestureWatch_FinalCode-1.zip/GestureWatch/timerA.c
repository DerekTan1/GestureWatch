/* Comments for all functions are located in the prototypes.h file */

#include <msp430.h>

int count_to_one_second = 0;

void ConfigureTimerA(void)
{
    TA0CTL = (MC_0 | TACLR);
    TA0CTL |= (TASSEL_1 | MC_1 | ID_3); /* TimerA/8 */
    TA0CCR0 = 3; /*511 512 = 1 sec (so set this to 511 because 0 counts) */
    TA0CCTL0 |= CCIE;
}
#pragma vector = TIMER0_A0_VECTOR
/*Timer a interrupt service routine */
__interrupt void TimerA0_routine(void)
{
    count_to_one_second++;
}
