/* Comments for all functions are located in the prototypes.h file */

#include <msp430.h>
#include "string.h"

void InitializeUART(void)
{
    P3SEL |= 0x30;                            /* P3.4,5 = USART0 TXD/RXD */
    ME1 |= UTXE0 + URXE0;                     /* Enable USART0 TXD/RXD */
    UCTL0 |= CHAR;                            /* 8-bit character */
    UTCTL0 |= SSEL1;                          /* UCLK= MCLK (hopefully) */
    UBR00 = 0x49; /* 8MHz 115200 was 0x45, changed to 0x49 because our clock is about 8.4MHz */
    UBR10 = 0x00;                             /* 8MHz 115200 */
    UMCTL0 = 0x00;                            /* 8MHz 115200 modulation */
    UCTL0 &= ~SWRST;                          /* Initialize USART state machine */
    IE1 |= URXIE0;                            /* Enable USART0 RX interrupt */
}

void SendUART(int data)
{
    while (!(IFG1 & UTXIFG0))
        ;                /* USART0 TX buffer ready? */
    TXBUF0 = data;                            /* RXBUF0 to TXBUF0 */
}

#pragma vector = USART0RX_VECTOR
__interrupt void UART_0_RX_isr(void)
{
    while (!(IFG1 & UTXIFG0))
    {
        continue;
    }
}

void SendStringToBluetooth(char str[])
{
    int i;
    for (i = 0; i < strlen(str); i++)
    {
        SendUART(str[i]);
    }
}
